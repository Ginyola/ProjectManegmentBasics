#include <iostream>

int main()
{
    std::cuot << "Hello World!" << std::endl;
}
#include <cstdio>

int main()
{
    std::puts("Hello World!");
}
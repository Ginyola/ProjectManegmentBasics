#include <cstdio>
#include <cmath>
#include <iostream>

int main()
{
    // 1. promtr user enter coeficients
    std::puts("Please, enter a, b and c for 'ax^2+bx+c=0' :");

    // 2. read coeficients for equation 'ax + b = 0'
    float a = 0;
    float b = 0;
    float c = 0;
    std::scanf("%f %f %f", &a, &b, &c);
    // discimenant
    float discr = (b * b) - (4 * a * c);
    std::printf("Roots:\n");
    std::cout << "First = " << std::sqrt(-discr / (2 * a)) << "\n";
    std::cout << "Second = " << std::sqrt(discr / (2 * a)) << "\n";
}
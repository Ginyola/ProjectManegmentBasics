#include <cstdio>

int main()
{
    // 1. promtr user enter coeficients
    std::puts("Please, enter a and b for 'ax + b = 0' :");

    // 2. read coeficients for equation 'ax + b = 0'
    float a = 0;
    float b = 0;
    std::scanf("%f %f", &a, &b);
    // solve equation
    // solution
    float x = -b / a;
    std::printf("soulution: %f\n", x);
}
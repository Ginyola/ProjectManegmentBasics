#include <cstdio>

int main()
{
    int a = 0;
    int b = 0;
    std::scanf("%d %d", &a, &b);
    std::printf("%d %d\n", a, b);
}
#include <iostream>

int main()
{
    std::cuot << "Hello Konstantin!" << std::endl;
}
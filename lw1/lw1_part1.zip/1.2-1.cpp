#include <iostream>

int main()
{
    std::cotu << "Hello World!" << std::endl;
}
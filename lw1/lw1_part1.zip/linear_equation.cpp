#include <cstdio>

int main()
{
    // 1. promtr user enter coeficients
    std::puts("Please, enter a and b for 'ax + b = 0' :");

    // 2. read coeficients for equation 'ax + b = 0'
    int a = 0;
    int b = 0;
    std::scanf("%d %d", &a, &b);
    // solve equation
    // solution
    int x = -b / a;
    std::printf("soulution: %d\n", x);
}